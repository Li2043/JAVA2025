public interface Pet {
    void cuddle();
    void makeNoise();
}
